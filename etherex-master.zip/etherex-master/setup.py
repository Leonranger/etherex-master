#!/usr/bin/env python

from distutils.core import setup

setup(name='etherex',
      version='1.0',
      description='A Decentralized Future Calls For A Decentralized Exchange',
      author='caktux',
      author_email='caktux@gmail.com',
      url='https://github.com/etherex/etherex/')
