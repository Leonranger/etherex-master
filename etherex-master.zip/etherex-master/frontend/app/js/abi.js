module.exports = {
  etherex: require('./abi/etherex'),
  sub: require('./abi/sub')
};
