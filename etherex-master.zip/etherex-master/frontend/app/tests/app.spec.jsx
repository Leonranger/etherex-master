// var React = require('react/addons');
// var TestUtils = React.addons.TestUtils;
// var expect = require('expect');

describe('EtherEx', function () {
  it('renders without problems', function (done) {
    require('../app');
    done();
  });
});
